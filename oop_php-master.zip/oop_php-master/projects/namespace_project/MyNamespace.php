<?php
namespace MyNamespace;

class MyClass {
    public function hello() {
        echo 'Hello from MyClass!';
    }
}

