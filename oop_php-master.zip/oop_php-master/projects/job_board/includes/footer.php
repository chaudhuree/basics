<footer>
    <p>&copy; 2023 Ostad</p>
</footer>
