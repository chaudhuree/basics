<header>
    <h1>Ostad Job Application</h1>
</header>
