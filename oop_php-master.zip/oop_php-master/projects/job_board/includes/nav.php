<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
    </ul>
</nav>
