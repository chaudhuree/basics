<!DOCTYPE html>
<html>
<head>
	<title>PHP Project</title>
</head>
<body>
	<form method="post" action="process.php">
		<label>Username:</label>
		<input type="text" name="username"><br><br>
		<label>Password:</label>
		<input type="password" name="password"><br><br>
		<button type="submit">Submit</button>
	</form>
</body>
</html>
