<?php
/*
22.02.2023
1.What is OOP?
1.classes
2.Object
3.Constructor
4.Access Modifiers
5.static
6.Examples/Projects
*/ 

/**
 * 23.02.2023
 * 1.Inheritance
 * 2. Student_Gradebook Project
 * 
 * */ 

/**
 * 25.02.2023
 * 1. Abstract class
 * 2. Shape Measurement Project
 * 3. Simple Login Project
 * 4. Rgb color conversion project
 * */  

/**
 * 26.02.2023
 * 1.Interfaces
 * 2. Object cloning
 * 3.Object to String
 * 4.Comparing Objects
 * 
 * */  

/**
 * 27.02.2023
 * 1.Namespace
 * 2.Trait
 * 
 * */  

/**
 * 28.02.2023
 * 1. Magic Methods
 * 2. final keyword
 * 3.Creating constants in classes
 * 4.Example project using Magic Methods, final keyword and constant
 * 
 * */  