<?php
print_r (glob('./uploads/*/*/*.jpg'));