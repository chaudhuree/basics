<?php
#Database Details
define("DB_HOST","127.0.0.1"); //localhost
define("DB_NAME","tasks");
define("DB_TABLE","tasks");
define("DB_USER","root");
define("DB_PASSWORD","mysql");