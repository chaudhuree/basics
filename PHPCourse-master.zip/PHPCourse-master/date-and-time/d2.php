<?php
date_default_timezone_set("Asia/Kolkata");
echo date('dS F, Y h:i:s A');
echo "\n";
echo date('t');



//20th December, 2018