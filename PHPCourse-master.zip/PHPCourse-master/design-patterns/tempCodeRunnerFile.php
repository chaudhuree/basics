<?php
// to_time_ago() function call 
echo timeAgo( time() - 443540);