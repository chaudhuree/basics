<?php
//session_name('myapp');
session_start();
echo $_SESSION['name'];