<?php
print_r(glob("*/*/*.php"));