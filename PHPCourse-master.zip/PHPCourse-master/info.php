<?php
echo mail("ggg","hello","Messge");