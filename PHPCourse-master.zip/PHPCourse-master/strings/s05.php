<?php
echo sha1("Hello");