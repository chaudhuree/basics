<?php
$color = array(122,233,65, 34);
// $red = $color[0];
// $green = $color[1];
// $blue = $color[2];

list($red, $green) = $color;

echo $green;

$student = array('Fname','Lname','Email','MobileNumber');
list($f, $l, $e, $m) = array('Fname','Lname','Email','MobileNumber');
echo $f;