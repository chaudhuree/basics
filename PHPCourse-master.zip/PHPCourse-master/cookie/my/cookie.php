<?php
echo $_COOKIE['username'];
