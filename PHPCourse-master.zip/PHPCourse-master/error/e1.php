<?php
//error_reporting(E_NOTICE );

echo 12/0;
echo $book;

// echo get_cfg_var("cfg_file_path");

