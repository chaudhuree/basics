<?php

class Shape{

}
class Rectangle extends Shape{
    function setHeight($height){
        
    }
    function setWidth($height){

    }
}

class Square extends Shape{

}