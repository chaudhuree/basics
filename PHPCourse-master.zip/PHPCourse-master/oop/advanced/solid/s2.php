<?php
class Student{
    function checkAttendencae(){}
    function calculateGrade(){}
    function collectFee(){}
}

class GradeCalculator{}

class Attendence{

} 

class StudentPayments{}