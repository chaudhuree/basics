<?php
class Bike{
    function getType(){
        echo "Motorcycle";
    }
}