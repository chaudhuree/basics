<?php
class Planet_Mars{
    function getName(){
        echo "Mars";
    }
}