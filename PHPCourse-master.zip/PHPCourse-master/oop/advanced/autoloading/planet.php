<?php
class Planet{
    function getName(){
        echo "Earth";
    }
}