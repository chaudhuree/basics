<?php
class Spaceship{
    function launch(){
        echo "T minus 3 2 1 0";
    }
}