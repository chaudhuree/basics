<?php
namespace Astronomy\Planets;
class Planet{
    function getName(){
        echo "Planet";
    }
}

