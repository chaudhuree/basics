<?php
$mailer = new Mailer();
        // $mailer->sendMail();

        // $scanner = new Scanner();
        // $scanner->scan();