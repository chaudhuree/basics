<?php
namespace CloudStorage\FileSystem\Files\Contracts;
interface ImageContract{
    function getDimension();
}