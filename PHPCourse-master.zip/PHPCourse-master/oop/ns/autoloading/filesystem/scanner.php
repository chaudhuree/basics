<?php
namespace CloudStorage\FileSystem;
class Scanner{
    function scan(){
        echo "Scanning\n";
    }
}