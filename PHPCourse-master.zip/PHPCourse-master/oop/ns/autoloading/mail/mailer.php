<?php 
namespace CloudStorage\Mail;
class Mailer{
    function sendMail(){
        echo "Sending Mail\n";
    }
}