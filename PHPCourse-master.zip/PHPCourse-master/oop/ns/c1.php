<?php
namespace Project;
class Bike{
    function getName(){
        return "KPR";
    }
}