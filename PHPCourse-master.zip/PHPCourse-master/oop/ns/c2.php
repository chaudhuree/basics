<?php
namespace Project\Motorcycles;
class Bike{
    function getName(){
        return "Hornet";
    }
}