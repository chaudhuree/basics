<?php
namespace Astronomy\Planets;
class Earth extends \Astronomy\Planets\Planet{
    function getName(){
        echo "Earth";
    }
}