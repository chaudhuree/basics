<?php
// Array Declaration
// Array Manipulation
// Detailed discussion of associative arrays
// Converting String to Array
// Converting Array to String
// Multiple Delimiters
// Multidimensional or nested arrays
// Associative Array to String Conversion - Serialize
// json
// Removing data from associative arrays
// Discussion of Empty Values
// Decluttering an array
// Concatenating
// Sorting
// Indexing
// Searching
// Array Utility Functions Walk
// Map
// Filter
// Reduce
// shuffling
// ASCII Code
// Accessing characters within a string
// String Reversing
// Breaking
// Searching
// trimming
// replacing
// WordWrap ​​