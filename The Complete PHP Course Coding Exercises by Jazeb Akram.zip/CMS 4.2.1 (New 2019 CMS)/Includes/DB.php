<?php
$DSN='mysql:host = localhost; dbname=cms4.2.1';
$ConnectingDB = new PDO($DSN,'root','');
?>
