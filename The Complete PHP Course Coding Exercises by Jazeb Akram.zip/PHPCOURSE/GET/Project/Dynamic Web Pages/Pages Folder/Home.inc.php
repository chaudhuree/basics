            <div id="content">
		<div id="latest"> <p>Latest Entries</p></div>
		<h1 class="contenthead">Top 10 British Films Of 2016  To Look Out For</h1>
           <p class="comment">1.01.16 # 23:41 # British Films # One Comment</p>
          	<div class="contentsmalldiv">
		    <img style="float: right;" src="newimages/1.jpg" alt=""/>
		<p>It looks like the year of the loser in British film, with a good number of titles focusing on our great love of the underdog. Plus fantasy adventure makes a bit of a comeback.
		It looks like the year of the loser in British film, with a good number of titles focusing on our great love of the underdog. Plus fantasy adventure makes a bit of a comeback. </p>
		</div>
		<div class="continue" ><a href="#" style="color: #B0B7CB; text-decoration: none" >continue reading>></a></div>
	  <div class="clear"></div> <hr>
	  <h1 class="contenthead">Action Movies 2016 &ndash; Guide</h1><!-- Special Characters https://www.utexas.edu/learn/html/spchar.html -->
           <p class="comment">1.01.16 # 16:09 # Action Movies # One Comment</p>
          	<div class="contentsmalldiv">
		    <img style="float: right;" src="newimages/2.jpg" alt=""/>
		<p>Boom. Lets take a look at the biggest and best action movies of 2016 with a Top 20 countdown. Its another huge year for superhero movies (Batman v Superman, Civil War, Dr.Strange etc), there are some long-awaited returns (Bourne 5, Independence Day 2, Kickboxer) and prepare yourself for another Star Wars. </p>
		</div>
		<div class="continue" ><a href="#" style="color: #B0B7CB; text-decoration: none" >continue reading>></a></div>
	  <div class="clear"></div> <hr>
	   <h1 class="contenthead">Horror Movies 2016  &ndash; Guide</h1>
           <p class="comment">1.01.16 # 14:05 # Horror Movies # 10 Comments</p>
          	<div class="contentsmalldiv">
		    <img style="float: right;" src="newimages/3.jpg" alt=""/>
		<p>Lets take a look at the biggest and best horror movies of 2016. The scary list features the usual mix of sequels (The Conjuring 2), prequels (Leatherface), reboots (Rings), and original fare (The Neon Demon). </p>
		</div>
		<div class="continue" ><a href="#" style="color: #B0B7CB; text-decoration: none" >continue reading>></a></div>
	  <div class="clear"></div> <hr>
	   <h1 class="contenthead">Comedy Movies 2016 &ndash; Guide</h1>
           <p class="comment">1.01.16 # 12:06 # Comedy Movies # 6 Comments</p>
          	<div class="contentsmalldiv">
		    <img style="float: right;" src="newimages/4.jpg" alt=""/>
		<p>Lets take a look at the biggest and best comedy movies of 2016. Funny this year comes in the form of De Niro as a dirty grandpa, Sacha Baron Cohen as a soccer hooligan, the return of Derek Zoolander, and Kevin Spacey turning into a cat. That and so much more. </p></div>
		<div class="continue" ><a href="#" style="color: #B0B7CB; text-decoration: none" >continue reading>></a></div>
	  <div class="clear"></div> <hr>
	  
	   <h1 class="contenthead">Star Wars: The Force Awakens &ndash; Review II (Midnight Movie Madness)</h1>
           <p class="comment">1.01.16 # 11:05 # Review # 4 Comments</p>
          	<div class="contentbigdiv">
		    <img style="display: block; margin: 0 auto;" src="newimages/5.jpg" alt=""/>
		<p style="font-size:1.2em;">As we transition to a new dawn I thought Id close things out with my review of the biggest film of last year, Star Wars: Episode VII &ndash;<strong><i> The Force Awakens. </i></strong></p>
		</div>
		<div class="continue" ><a href="#" style="color: #B0B7CB; text-decoration: none" >continue reading>></a></div>
	  <div class="clear"></div> <hr>
	  <h1 class="contenthead">Top 5 Worst Movies Of 2015</h1>
           <p class="comment">28.12.15 # 14:27 # Top Ten # 5 Comments</p>
          	<div class="contentbigdiv">
		    <img style="display: block; margin: 0 auto;" src="newimages/6.jpg" alt=""/>
		<p style="font-size:1.2em;">Normally Id actively avoid movies with a reputation as one of Satans bile burps, but sometimes the responsibilities of Movie-Moron back me into a corner. Other times Im blindsided out of nowhere, caught unawares with my cinematic pants down. </p>
		</div>
		<div class="continue" ><a href="#" style="color: #B0B7CB; text-decoration: none" >continue reading>></a></div>
	  <div class="clear"></div> <hr>
	  <h1 class="contenthead">Star Wars: The Force Awakens &ndash; Review (No Spoilers)</h1>
           <p class="comment">17.12.15 # 4:44 # Review # 16 Comments</p>
          	<div class="contentbigdiv">
		    <img style="display: block; margin: 0 auto;" src="newimages/7.jpg" alt=""/>
		<p style="font-size:1.2em;">J.J. did it! Well in so much as nothing will ever capture the magic of the original trilogy, but this gives it a damn good try, helped along massively by one of the stars of that trilogy. </p>
		</div>
		<div class="continue" ><a href="starwars.html" target="_blank" style="color: #B0B7CB; text-decoration: none" >continue reading>></a></div>
	  <div class="clear"></div> <hr>
	  <h1 class="contenthead">The Hunger Games: Mockingjay Part 2&ndash;  Review (Midnight Movie Madness)</h1>
           <p class="comment">17.12.15 # 3:50 # Review # No Comment</p>
          	<div class="contentbigdiv">
		    <img style="display: block; margin: 0 auto;" src="newimages/8.jpg" alt=""/>
		<p style="font-size:1.2em;">As the war of Panem escalates to the destruction of other districts, Katniss Everdeen, the reluctant leader of the rebellion, must bring together an army against President Snow, while all she holds dear hangs in the balance.The final chapter in the popular franchise goes dark but does it stray from the book where it needs to? </p>
		</div>
		<div class="continue" ><a href="hunger.html" target="_blank" style="color: #B0B7CB; text-decoration: none" >continue reading>></a></div>
	  <div class="clear"></div> <hr>
	  <h1 class="contenthead">What Did You Watch This Week? (Reviews Of Slow West, Mr Holmes, Cooties, The Nightmare, Cub & Howl)</h1>
           <p class="comment">4.12.15 # 2:27 # Review # 4 Comments</p>
          	<div class="contentsmalldiv">
		    <img style="float: right;" src="newimages/9.jpg" alt=""/>
		<p>Short reviews of Michael Fassbender western Slow West, Ian McKellen as Mr. Holmes, horror-comedy Cooties, spooky documentary The Nightmare, Belgian scout camp terror Cub, and werewolves on a British train in Howl</p>
		</div>
		<div class="continue" ><a href="#" style="color: #B0B7CB; text-decoration: none" >continue reading>></a></div>
	  <div class="clear"></div> <hr>
	  <h1 class="contenthead">Bridge Of Spies &ndash; Review (Midnight Movie Madness)</h1>
           <p class="comment">3.12.15 # 16:44 # Review # 3 Comments</p>
          	<div class="contentbigdiv">
		    <img style="display: block; margin: 0 auto;" src="newimages/10.jpg" alt=""/>
		<p style="font-size:1.2em;">The outcome of the Cold War lies in the hands of Tom Hanks and his very handsome hat.	 </p>
		</div>
		<div class="continue" ><a href="#" style="color: #B0B7CB; text-decoration: none" >continue reading>></a></div>
	  <div class="clear"></div> <hr>
	  
          	<div class="contentbigdiv">
		    <img style="display: block; margin: 0 auto;" src="newimages/11.jpg" alt=""/>
	    
		</div>
		 <div class="clear"></div>
	    <h1 class="contenthead">Follow&ndash;Us</h1>
	    <div id="social">
		<ul>
<li style="margin-left: -20px;"><a href="https://www.facebook.com/jazeb.akram" target="_blank"><img src="images/fb.png" alt="facebook"/></a></li>
<li><a href="https://twitter.com/jazebakram"target="_blank"><img src="images/tweet.png" alt="tweeter"/></a></li>
<li><a href="https://plus.google.com/+jazebakram/posts"target="_blank"><img src="images/google.png" alt="G+"/></a></li>
<li><a href="https://www.youtube.com/channel/UChLQHgrd2LU1lpn_Q_uXAWA"target="_blank"><img src="images/youtube.png" alt="youtube"/></a></li>
 <li><a href="https://www.linkedin.com/in/jazebakram"target="_blank"><img src="images/link.png" width="110px" height="105px;" alt="linkdIn"/></a></li>
		</ul>
	    </div>
	    
	    	  <div class="clear"></div>
		</div>
	  <div class="clear"></div>
	 
	  