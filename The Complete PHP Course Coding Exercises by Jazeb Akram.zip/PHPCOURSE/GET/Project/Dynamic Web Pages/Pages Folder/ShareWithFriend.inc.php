<style>
    section.action{
        background: rgb(168,88,163);
    }
    section.animation{
        background:rgb(251,174,44);
    }
    section.upcoming{
        background:rgb(2,99,174);
    }
    section.comedy{
	background: rgb(92, 92, 92);
    }
    section.info{
        width:300px;
        max-height: 320px;
        overflow:hidden;
        float: left;
        margin: 3px 3px 0 0;

      border-top-left-radius: 20px;
      border-top-right-radius: 20px;
       border-bottom-left-radius: 30px;
      border-bottom-right-radius: 30px;
    }
  section.info img{
    display: block;
    margin: 0auto 2em;
    padding-left: 5px;
    
   }
   section.info h2{
    font-size: 1.9em;
    font-weight: 200;font-family: bitter,georgia,times,"Times New Roman",serif;
   padding-left: .5em;
   line-height: 40px;
   background: url(images/pattern.png);
   color: rgb(350,400,31);
   }
   section.info p ,section.info ul{
    list-style:circle;
    margin: 0 1.2em 1em;
    
   }
   section.info li{
    font-size: 1.2em;
    color:rgb(251,174,44);
    margin-bottom: .8em;
   }
 section.info .date{
    font-weight:bold;
    color: white;
    display: block;
 }
    
</style>            <div>
    <section class="action info">
        <h2>Action Movies</h2>
        <img src="images/action.jpg" width="290" height="250" alt="action">
        
       
    </section>
    <section class="comedy info">
        <h2>Comedy Movies</h2>
        <img src="images/bean.jpg" width="290" height="250" alt="action">
        
          </section>
     <section class="animation info">
        <h2>Animated Movies</h2>
         <img src="images/34.jpg" width="290" height="250" alt="action">
        
    </section>
      <section class="upcoming info">
        <h2>Upcoming Movies</h2>
         <img src="images/upcoming.jpg" width="290" height="250" alt="action">
       
    </section></div>
	    <div class="clear"></div>
	    <h1 class="contenthead">Follow Us</h1>
	    <div id="social">
		<ul>
<li style="margin-left: -20px;"><a href="https://www.facebook.com/jazeb.akram" target="_blank"><img src="images/fb.png" alt="facebook"/></a></li>
<li><a href="https://twitter.com/jazebakram"target="_blank"><img src="images/tweet.png" alt="tweeter"/></a></li>
<li><a href="https://plus.google.com/+jazebakram/posts"target="_blank"><img src="images/google.png" alt="G+"/></a></li>
<li><a href="https://www.youtube.com/channel/UChLQHgrd2LU1lpn_Q_uXAWA"target="_blank"><img src="images/youtube.png" alt="youtube"/></a></li>
 <li><a href="https://www.linkedin.com/in/jazebakram"target="_blank"><img src="images/link.png" width="110px" height="110px;" alt="linkdIn"/></a></li>
		</ul>
	    </div>
	    
	    <div class="clear"></div>