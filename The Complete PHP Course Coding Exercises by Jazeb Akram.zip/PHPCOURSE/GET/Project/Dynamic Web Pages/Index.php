<!doctype html>
<html>
<head>
    <title>Index Page Having Common Structure</title>

    <meta charset="utf-8" />
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
 
 <link rel="stylesheet" href="CSS/Basic.css">
    <style>
#menu{
    background-color: rgb(200, 200, 200);
    border: 2px solid #5D0580;
    
}
#menu ul li{
    float: left;
    font-size: 1.6em;
    margin-top:-7px;
    font-weight:bold;
    font-family: bitter,georgia,times,"Times New Roman",serif;
    
}

#menu ul{
    list-style: none;
    margin-bottom: 0px;
    
    height: 30px;
    border-bottom: 1px solid #000;
}

#menu ul li a{
    
    display: block;
    color: #000;
    text-decoration: none;
    padding: 0 20px;
    line-height: 30px;
}

#menu ul li a:hover,#menu ul li a.selected
{
    background: url("images/pattern.png");
    background-color: #5D0580;
    color: #fff; 
}
    
    #social{
   
    
}

#social ul li{
    float: left;
    margin-left: 10px;
    margin-top: 15px;
    list-style: none;
}
section.links h3{
    background: rgba(0, 0, 0, 0) url("images/pattern.png") repeat scroll 0 0;
    color: white;
    font-family: Bitter,Georgia,Times,"Times New Roman",serif;
    font-size: 1.9em;
    font-weight: 100;
    line-height: 45px;
   display: block;

}
section.links{
height: 300px;
}
section.links ul{
    margin-left: -30px;
   
}
section.links li{
    list-style: none;
    padding-top: 10px;
    
}
section.links li a{
    background-color: #fbae2c;
    display: block;
    list-style: none;
    font-size: 1.1em;
 
    line-height: 30px;
    text-decoration: none;
    color: white;
	
    }
section.links li a:hover{
    background: url("images/pattern.png");
    display: block;
    list-style: none;
    font-size: 1.3em;
    font-weight: bold;
    line-height: 30px;
    text-decoration: none;
    padding-left: 25px;
    color: white;
   border-bottom-left-radius: 15px;
   border-bottom-right-radius: 15px;
   border-top-left-radius: 15px;
   border-top-right-radius: 15px;
   background-color:#5D0580;/*rgba(168,88,163,1);*/
    }
   

h2,legend{
    color: White;
    font-size: 1.6em;  
background: url("images/pattern.png");
font-family: Bitter,Georgia,Times,"Times New Roman",serif;
text-align: center;
background-color:#5D0580;

}

#request{
    color: rgb(251, 174, 44);
    font-family: Bitter,Georgia,"Times New Roman",Times,serif;
    font-size: 3.0em;
    line-height: 1.9em;
    font-weight: bold;

    
}
.req{
     font-size: 1.2em;
      font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
}


</style>
    
</head>
<body>
    <div id="wrap">
        <div id="header">
            <div id="logo">
	<!--	<img id="mainImage" src="images/bournelegacy.jpg" width="990" height="400" alt="image"/> -->
	    </div>
        </div>
        <div id="menu">
            <ul>
<li><a href="Index.php">Home</a></li>
<li><a href="Index.php?PageName=About" >About Us </a></li>
<li><a href="Index.php?PageName=Contact">Contact Us</a></li>
<li><a href="Index.php?PageName=ShareWithFriend">Tell a friend</a></li>
<li><a href="">Coming Soon</a></li>
<li><a href="">Forum</a></li>
            </ul>
 <div class="clear"></div>
 </div>
        <!-- Main Area Content Area -->
        <div id="main">
<div id="content">
<?php
$PagesDirectory='Pages Folder';
if(!empty($_GET['PageName']))
{

$PagesFolder=scandir($PagesDirectory,0);
unset($PagesFolder[0],$PagesFolder[1]);
$PageName=$_GET['PageName'];
if(in_array($PageName.'.inc.php',$PagesFolder)){
include($PagesDirectory.'/'.$PageName.'.inc.php');    
}else{
    echo '<h1 id="request">You are Lost..</h1>';
echo '<img src="Images/Lost.gif" width="680" height="430">';
    
    echo '<h2>Sorry Page Not Found</h2>';
}

}
else{
    include($PagesDirectory.'/Home.inc.php');
}
?>
 	
	  <div class="clear"></div>	  	 

 </div>
	    
         <!-- Side Area -->
            <div id="side">
    <section class="links">
	    <h3 >Latest Movie Links</h3>
	    <ul>
		<li><a href="#">Action Movies</a></li>
		<li><a href="#">Animated Movies</a></li>
		<li><a href="#">Comedy Movies</a></li>
		<li><a href="#">Drama Movies</a></li>
		<li><a href="#">Horror Movies</a></li>
		
	    </ul>
	     </section>
	   <h2 style="background: url(images/pattern.png);">Today's Top Movies</h2>
	    <section class="sideimage">
	    <img src="images/V.jpg" width="270" height="120" alt=""/>
	    
	    <h4 style="background: url(images/pattern.png);">V for Vandetta</h4>
	   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <a href="#">More</a>
	   </p></section>
	    <br>
	   <div class="clear"></div>
	   <section class="sideimage">
	    <img src="images/jokerthegreat.jpg" width="270" height="120" alt=""/>
	    
	    <h4 style="background: url(images/pattern.png);">Joker</h4>
	   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <a href="#">More</a>
	   </p>
	 </section>
	 
	   </p><br><br><br><br><br></section>
	   <div class="clear"></div>
	   <br>
	    </div>
   
            <div class="clear"></div>
        </div>
        <!-- Footer Area -->
        <div id="footer"><hr><p>Theme By | Jazeb Akram |&copy;2016-2019 All right reserved.
	<br><a style="color: white; text-decoration: none; cursor: pointer; font-weight:bold;" href="jazebakram.com/coupons" target="_blank">Build reponsive website with html5 and css from scratch.</a>
	<br><a style="color: white; text-decoration: none; cursor: pointer; font-weight:bold;" href="jazebakram.com/coupons" target="_blank">Javascript complete and comprehensive for beginners. </a>
	<br>CSS Animations & Design for UI UX Designers. finally the best course for moderen deigner is out. after previous skillfull courses. 
	This site is only used for Study purpose jazebakram.com have all the rights. no one is allow to distribute
	copies other then <br>&trade; jazebakram.com &trade;  Udemy ; &trade; Skillshare ; &trade; StackSkills</p><hr>
	   
	</div>
        
        
       <div style="height: 20px; background: rgb(200, 200, 200);"></div> 
    </div>
<script src="Script/Myscript.js"></script>
</body>
</html>