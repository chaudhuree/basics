<!DOCTYPE>

<html lang="en">
	<head>
		<title>Hello World</title>
	</head>
	<body>
	<h1>Jazeb</h1>
		<?php echo "Hello World!"; ?><br />
		<?php echo "Hello" . " World!"; ?><br />
		<?php echo 2 + 3; 
		phpinfo(); ?>
		
		
	</body>
</html>
