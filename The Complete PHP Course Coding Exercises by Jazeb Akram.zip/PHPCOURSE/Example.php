<!DOCTYPE>
<html>
	<head>
		<title>untitled</title>
	</head>
	<body>
<h1>MY Bio<h1>
<?php 
 //my name is jazeb akram
/*klla
asas
asas
saas

asas*/
echo "my name is Jazeb";

 ?><br>
 <?php echo "who is ali";  ?> <br>
 <?php echo "what his age";  ?><br>
 <?php echo 5+9+6;  ?>
<?php 

	phpinfo();
	
?>
	</body>
</html>