<!DOCTYPE>

<html>
	<head>
<title>Branching Statements </title>
	</head>
	<body>
<?php ?>
<?php
$Names=array("jazeb","akram","Ali","Alex","Tait","Shaan","David","Roth");
for($i=0;$i<=7;$i++){
if($Names[$i]=="Alex"){
break; //continue;
	}
	echo $Names[$i]. "<br>";
	
} 

?>


	    
	</body>
</html>
